import React, { Component } from 'react'
import Form from '../component/Form'
import ListIzquierda from '../component/ListIzquierda'


export default class Home extends Component {
    render() {
        return (
            <div>
                <div className="container">
                    <div className="row">
                        <Form />
                        <ListIzquierda />
                    </div>
                </div>
            </div>
        )
    }
}
