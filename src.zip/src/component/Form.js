import React, { Component } from 'react'
import ListDerecha from './ListDerecha'


export default class Form extends Component {
    render() {
        return (
            <div className="col-md-6">
                <div className="todolist not-done">
                    <input type="text" className="form-control add-todo" placeholder="Add todo" />
                    <button id="checkAll" className="btn btn-success">Mark all as done</button>
                    <br />
                    <br />
                    <ListDerecha />
                    <div class="todo-footer">
                        <strong><span class="count-todos"></span></strong> Items Left
                        </div>
                </div>
            </div>

        )
    }
}
