import React, { Component } from 'react'

export default class ListIzquierda extends Component {
    render() {
        return (
            <div className="col-md-6">
                <div className="todolist">
                    <h1>Already Done</h1>
                    <ul id="done-items" className="list-unstyled">
                        <li>Some item <button className="remove-item btn btn-default btn-xs pull-right">X<span class="glyphicon glyphicon-remove"></span></button></li>

                    </ul>
                </div>
            </div>
        )
    }
}
