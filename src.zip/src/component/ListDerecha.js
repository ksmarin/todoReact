import React from 'react'

const List = () => {
    return (
            <>
                <li className="ui-state-default">
                    <div className="checkbox">
                        <label>
                            <input type="checkbox" value="" />Take out the trash
                        </label>
                    </div>
                </li>
            </>
        )
    }

export default function ListDerecha() {

    return (
        <>
            <ul id="sortable" className="list-unstyled">
                <List />
            </ul>
        </>
    )
    
}
