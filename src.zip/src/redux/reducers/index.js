import { combineReducers } from 'redux';
import tareas from './tareas.reducer';

export default conbineReducers({
    tareas
})