import { AGREGAR_TAREA, FINALIZAR_TAREA, ELIMINAR_TAREA } from './../actions/tarea.action'

const init = {
    tareas : [],
    loading : false
}


export default (state = init, action) =>{
    switch (action.type) {
        case AGREGAR_TAREA:
            let tareas = {...state}
            break;
        case FINALIZAR_TAREA:
            
            break;
        case ELIMINAR_TAREA:
            
            break;
    
        default:
            return state;
            break;
    }

}